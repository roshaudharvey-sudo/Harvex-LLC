# Harvex Lawn Care

Harvex Lawn Care website with online booking, Stripe Checkout, 65-mile service-area validation, Wednesday-Friday scheduling blocks, employee authentication, and a dedicated owner portal.

## Owner login

Set these Render environment variables:

- `OWNER_LOGIN_EMAIL` — the email you want to use to sign in
- `OWNER_LOGIN_PASSWORD` — a strong owner password (do not put this in GitHub)
- `SESSION_SECRET` — a long random secret used to sign sessions

Then visit `/owner-login.html`.

The owner login redirects to `/owner-dashboard.html`. Employee accounts continue to use `/employee-login.html`.

## Email notifications

Set `RESEND_API_KEY`, `RESEND_FROM`, and `OWNER_EMAIL` in Render to enable booking notification emails.


## Paid booking notifications

The owner notification is sent only after Stripe reports `checkout.session.completed` with `payment_status=paid`.

Set these Render environment variables:

- `RESEND_API_KEY`
- `RESEND_FROM` (a verified Resend sender, e.g. `Harvex <bookings@your-verified-domain>`)
- `OWNER_EMAIL` (the email address that should receive booking alerts)
- `STRIPE_WEBHOOK_SECRET`

In Stripe Dashboard, create a webhook endpoint pointing to:

`https://harvexlawncare.com/api/stripe/webhook`

Subscribe it to the `checkout.session.completed` event, then copy the endpoint's signing secret (`whsec_...`) into Render as `STRIPE_WEBHOOK_SECRET`.

Do not put any of these secrets in GitHub.
