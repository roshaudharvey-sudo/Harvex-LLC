# Harvex Lawn Care

Harvex Lawn Care website with online booking, Stripe Checkout, 65-mile service-area validation, Wednesday-Friday scheduling blocks, employee authentication, and a dedicated owner portal.

## Owner login

Set these Render environment variables:

- `OWNER_LOGIN_EMAIL` — the email you want to use to sign in
- `OWNER_LOGIN_PASSWORD` — a strong owner password (do not put this in GitHub)
- `SESSION_SECRET` — a long random secret used to sign sessions

Then visit `/owner-login.html`.

The owner login redirects to `/owner-dashboard.html`. Employee accounts continue to use `/employee-login.html`.

## Email notifications

Set `RESEND_API_KEY`, `RESEND_FROM`, and `OWNER_EMAIL` in Render to enable booking notification emails.
